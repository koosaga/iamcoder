#include <cstdio>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
typedef long long lint;
typedef pair<lint,int> pi;

vector<int> v[50005];
vector<int> lab[50005];
vector<pi> graph[200500];

int n,m,l[50005],piv;
int t1[100005], s1[100005], t2[100005], s2[100005], x[100005];

void add_edge(int s, int e, int x){
    graph[s].push_back(pi(x,e));
    graph[e].push_back(pi(x,s));
}

int t3, s3, t4, s4;

priority_queue<pi,vector<pi>,greater<pi> > pq;
int vis[200500];

lint dijkstra(int s, int e){
    pq.push(pi(0,s));
    while (!pq.empty()) {
        pi t = pq.top();
        pq.pop();
        if(t.second == e) return t.first;
        if(vis[t.second]) continue;
        vis[t.second] = 1;
        for (int i=0; i<graph[t.second].size(); i++) {
            pi j = graph[t.second][i];
            pq.push(pi(t.first + j.first,j.second));
        }
    }
    return -1;
}

int main(){
    scanf("%d %d",&n,&m);
    for (int i=1; i<=n; i++) {
        scanf("%d",&l[i]);
    }
    for (int i=0; i<m; i++) {
        scanf("%d %d %d %d %d",&t1[i],&s1[i],&t2[i],&s2[i],&x[i]);
        v[t1[i]].push_back(s1[i]);
        v[t2[i]].push_back(s2[i]);
    }
    scanf("%d %d %d %d",&t3,&s3,&t4,&s4);
    v[t3].push_back(s3);
    v[t4].push_back(s4);
    for (int i=1; i<=n; i++) {
        sort(v[i].begin(),v[i].end());
        v[i].resize(unique(v[i].begin(),v[i].end()) - v[i].begin());
        lab[i].resize(v[i].size());
        for (int j=0; j<v[i].size(); j++) {
            lab[i][j] = ++piv;
        }
        for (int j=0; j<v[i].size()-1; j++) {
            add_edge(lab[i][j],lab[i][j+1],2 * (v[i][j+1] - v[i][j]));
        }
    }
    for (int i=0; i<m; i++) {
        int p1 = (int)(lower_bound(v[t1[i]].begin(),v[t1[i]].end(),s1[i]) - v[t1[i]].begin());
        int p2 = (int)(lower_bound(v[t2[i]].begin(),v[t2[i]].end(),s2[i]) - v[t2[i]].begin());
        add_edge(lab[t1[i]][p1],lab[t2[i]][p2],x[i]);
    }
    s3 = (int)(lower_bound(v[t3].begin(),v[t3].end(),s3) - v[t3].begin());
    s4 = (int)(lower_bound(v[t4].begin(),v[t4].end(),s4) - v[t4].begin());
    printf("%lld",dijkstra(lab[t3][s3],lab[t4][s4]));
}