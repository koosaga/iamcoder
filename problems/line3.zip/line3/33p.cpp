#include <cstdio>
#include <cstring>

int a[3005][3005];
int dp[3005][3005];
int n,k;

int cost(int i, int j){
    return a[j][j] - a[i-1][j] - a[j][i-1] + a[i-1][i-1];
}

int main(){
    char s[3005];
    scanf("%d %d",&n,&k);
    for (int i=1; i<=n; i++) {
        scanf("%s",s);
        for (int j=1; j<=n; j++) {
            a[i][j] = s[j-1] - '0' + a[i][j-1] + a[i-1][j] - a[i-1][j-1];
        }
    }
    memset(dp,0x3f,sizeof(dp));
    dp[1][1] = 0;
    for (int i=2; i<=k; i++) {
        for (int j=i; j<=n; j++) {
            for (int k=i-1; k<j; k++) {
                if(dp[i][j] > dp[i-1][k] + cost(k,j)){
                    dp[ai][j] = dp[i-1][k] + cost(k,j);
                }
            }
        }
    }
    printf("%d",dp[k][n]);
}