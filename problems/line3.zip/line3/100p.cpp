#include <cstdio>
#include <cstring>

int a[3005][3005];
int dp[3005][3005];
int n,k;

int cost(int i, int j){
    return a[j][j] - a[i-1][j] - a[j][i-1] + a[i-1][i-1];
}

void solve(int c, int s, int e, int is, int ie){
    if(s > e) return;
    if(s == e){
        for (int i=is; i<=ie; i++) {
            if(dp[c][s] > dp[c-1][i] + cost(i,s)){
                dp[c][s] = dp[c-1][i] + cost(i,s);
            }
        }
    }
    int m = (s+e)/2, opt = -1;
    for (int i=is; i<=ie; i++) {
        if(dp[c][m] > dp[c-1][i] + cost(i,m)){
            dp[c][m] = dp[c-1][i] + cost(i,m);
            opt = i;
        }
    }
    solve(c,s,m-1,is,opt);
    solve(c,m+1,e,opt,ie);
}

int main(){
    char s[3005];
    scanf("%d %d",&n,&k);
    for (int i=1; i<=n; i++) {
        scanf("%s",s);
        for (int j=1; j<=n; j++) {
            a[i][j] = s[j-1] - '0' + a[i][j-1] + a[i-1][j] - a[i-1][j-1];
        }
    }
    memset(dp,0x3f,sizeof(dp));
    dp[1][1] = 0;
    for (int i=2; i<=k; i++) {
        solve(i,i,n+(i-k),i-1,n-1);
        continue;
    }
    printf("%d",dp[k][n]);
}
