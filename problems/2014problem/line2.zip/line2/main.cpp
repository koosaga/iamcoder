#include <cstdio>
#include <algorithm>
using namespace std;

int a[500005];
int n,m;
long long p,q;

long long calc[500005];

long long getmax(){
    long long ret = 0;
    long long mv = 0, cmv = 0;
    for (int i=1; i<=n; i++) {
        ret -= q * a[i];
        calc[i] = p * a[i] + q * (2 * a[i] - m);
    }
    for (int i=1; i<=n; i++) {
        mv += calc[i];
        if(mv < 0) mv = 0;
        cmv = max(mv,cmv);
    }
    return ret + cmv;
}

long long getmax2(){
    long long ret = 0;
    long long mv = 0, cmv = 0;
    for (int i=1; i<=n; i++) {
        ret += p * a[i] - q * (m - a[i]);
        calc[i] = -calc[i];
    }
    for (int i=1; i<=n; i++) {
        mv += calc[i];
        if(mv < 0) mv = 0;
        cmv = max(mv,cmv);
    }
    return ret + cmv;
}

int main(){
    scanf("%d %d %lld %lld",&n,&m,&p,&q);
    for (int i=0; i<m; i++) {
        int s,e;
        scanf("%d %d",&s,&e);
        if(s <= e){
            a[s]++;
            a[e+1]--;
        }
        else{
            a[1]++;
            a[e+1]--;
            a[s]++;
            a[n+1]--;
        }
    }
    for (int i=1; i<=n; i++) {
        a[i] += a[i-1];
    }
    long long res = getmax();
    res = max(res,getmax2());
    if(res < 0) puts("FAIL");
    else printf("%lld",res);
}