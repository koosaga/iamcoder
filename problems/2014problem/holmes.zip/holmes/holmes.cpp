#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <utility>
using namespace std;
typedef pair<int,int> pi;

int n,m;
vector<int> graph[5005];
vector<int> res[5005];

int is_cut[5005], found = 0;
int dfn[5005], piv;

pi calc_cut(int x, int root, int no){
    int cr = dfn[x] = ++piv;
    int child = 0;
    int reached = (x == n);
    for (int i=0; i<graph[x].size(); i++) {
        if(graph[x][i] == no) continue;
        if(dfn[graph[x][i]] == 0){
            child++;
            pi sub = calc_cut(graph[x][i],0,no);
            reached |= sub.second;
            if(sub.first >= dfn[x] && root == 0 && sub.second){
                is_cut[x] = 1;
                found++;
            }
            cr = min(cr,sub.first);
        }
        else{
            cr = min(cr,dfn[graph[x][i]]);
        }
    }
    return pi(cr,reached);
}

void calc_alone(){
    calc_cut(1,1,0);
    if(!found) return;
    puts("Holmes win!");
    for (int i=2; i<n; i++) {
        if(is_cut[i]) printf("%d\n",i);
    }
}

int calc_without(int x){
    calc_cut(1,1,x);
    for (int i=x+1; i<n; i++) {
        if(is_cut[i]) res[x].push_back(i);
    }
    return (int)res[x].size();
}

void calc_with(){
    int ress = 0;
    for (int i=2; i<n; i++) {
        memset(is_cut,0,sizeof(is_cut));
        memset(dfn,0,sizeof(dfn));
        ress += calc_without(i);
    }
    if(ress == 0){
        puts("Lupin win!");
        return;
    }
    puts("Holmes and Watson win!");
    for (int i=2; i<n; i++) {
        for (int j=0; j<res[i].size(); j++) {
            printf("%d %d\n",i,res[i][j]);
        }
    }
}

int main(){
    scanf("%d %d",&n,&m);
    for (int i=0; i<m; i++) {
        int x,y;
        scanf("%d %d",&x,&y);
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    calc_alone();
    if(!found) calc_with();
}