#include <cstdio>
#include <list>
#include <algorithm>
using namespace std;

int n,a[1000005];
int vis[1000005];
int fact[1000005];

int get_comp(int x){
    int res = 0;
    while (!vis[x]) {
        vis[x] = 1;
        x = a[x];
        res++;
    }
    return res;
}

int main(){
    scanf("%d",&n);
    list<int> l;
    for (int i=1; i<=n; i++) {
        l.push_back(n-i+1);
    }
    list<int> ::iterator it = l.begin();
    for (int i=1; i<=n; i++) {
        a[i] = *it;
        it = l.erase(it);
        if(it == l.end()) it = l.begin();
        it++;
        if(it == l.end()) it = l.begin();
    }
    for (int i=1; i<=n; i++) {
        int r = get_comp(i);
        for (int j=2; j*j<=r; j++) {
            int cnt = 0;
            while(r%j == 0) r /= j, cnt++;
            fact[j] = max(fact[j],cnt);
        }
        if(r != 1) fact[r] = max(fact[r],1);
    }
    long long res = 1, mod = 1e9 + 7;
    for (int i=1; i<=n; i++) {
        for (int j=0; j<fact[i]; j++) {
            res *= i;
            res %= mod;
        }
    }
    printf("%lld",res);
}