#include <cstdio>
#include <algorithm>
using namespace std;

int a,b,c,k;
long long dp[300005];

int main(){
    scanf("%d %d %d %d",&a,&b,&c,&k);
    dp[1] = a;
    for (int i=2; i<=k; i++) {
        dp[i] = dp[i-1] + a;
        for (int j=1; j*j<=i; j++) {
            if(i%j == 0){
                if(i != j) dp[i] = min(dp[i],dp[j] + b + 1ll * (i/j - 1) * c);
                if(i != 1) dp[i] = min(dp[i],dp[i/j] + b + 1ll * (j-1) * c);
            }
        }
    }
    printf("%lld",dp[k]);
}
