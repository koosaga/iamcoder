#include<cstdio>

int count[1000002];
int diff[1000002];
int sum[1000002];

int main()
{	
	int N,T;
	scanf("%d%d",&N,&T);
	int tmp,k;
	for(int i=1;i<=T;i++)
	{
		scanf("%d",&tmp);
		count[tmp]++;
		k=count[tmp];
		
		if(k<=(N-1)/2)
		{
			if(tmp-k>0)
			{
				diff[tmp-k]++; diff[tmp]--;
			}
			else
			{
				diff[1]++; diff[tmp]--;
				diff[tmp-k+N]++;
			}
			
			if(tmp+k<=N)
			{
				diff[tmp+1]++; diff[tmp+k+1]--;
			}
			else
			{
				diff[tmp+1]++;
				diff[1]++; diff[tmp+k-N+1]--;
			}
		}
		
		else if(k<N)
		{
			diff[1]++; diff[tmp]--;
			diff[tmp+1]++;
		}
		
		else
		{
			diff[1]++;
		}
	}
	
	
	for(int i=1;i<=N;i++)
	{
		sum[i] = sum[i-1] + diff[i];
		printf("%d\n",sum[i]);
	}	
} 
