#include <stdio.h>
#include <cstring>
#include <algorithm>
using namespace std;
int arr[100][100],n,m;

void del(int x,int y)
{
    int i;
    for(i = max(x-3,-n); i <= min(x+3,n); i++){
        arr[n+i][m+y]=0;
    }
    for(i = max(y-3,-m); i <= min(y+3,m); i++){
        arr[n+x][m+i]=0;
    }
}

void timegoes()
{
    int temp[100][100]={};
    int i,j;
    for(i=0;i<=2*n;i++)
    {
        for(j=0;j<=2*m;j++)
        {
            temp[i][j]+=arr[i][j];
            if(i) temp[i][j]+=arr[i-1][j];
            if(i+1 <= 2*n) temp[i][j]+=arr[i+1][j];
            if(j) temp[i][j]+=arr[i][j-1];
            if(j+1 <= 2*m) temp[i][j]+=arr[i][j+1];
        }
    }
    memcpy(arr,temp,sizeof(arr));
}

int main()
{
    int i,j,a,b,k,t,p,x,y;
    scanf("%d%d%d",&n,&m,&k);
    scanf("%d%d",&a,&b);
    arr[n][m] = 1;
    for(i=1;i<=k;i++)
    {
        scanf("%d%d",&t,&p);
        for(j=1;j<=t;j++) timegoes();
        for(j=1;j<=p;j++)
        {
            scanf("%d %d",&x,&y);
            del(x,y);
        }
    }
    printf("%d",arr[n+a][m+b]);
}
