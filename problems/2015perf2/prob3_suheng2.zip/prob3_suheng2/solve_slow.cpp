#include <cstdio>
const int mod = 1e9 + 7;

int dp[100005], cnt[105000], nxt[100005], sum[100005];
int a[100005], n, m;

int main(){
    scanf("%d %d",&n,&m);
    for (int i=1; i<=n; i++) {
        scanf("%d",&a[i]);
    }
    dp[n+1] = 0;
    cnt[n+1] = 1;
    for (int i=1; i<=m; i++) {
        nxt[i] = n+1;
    }
    for (int i=n; i>=0; i--) {
        dp[i] = 1e9;
        nxt[a[i+1]] = i+1;
        for (int j=1; j<=m; j++) {
            int low = nxt[j];
            if(dp[i] > dp[low] + 1){
                dp[i] = dp[low] + 1;
                cnt[i] = cnt[low];
            }
            else if(dp[i] == dp[low] + 1){
                cnt[i] += cnt[low];
                cnt[i] %= mod;
            }
        }
    }
    printf("%d %d",dp[0],cnt[0]);
}