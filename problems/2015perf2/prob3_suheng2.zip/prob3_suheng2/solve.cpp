#include <cstdio>
#include <algorithm>
using namespace std;
const int mod = 1e9 + 7;

int dp[100005], cnt[100005], nxt[100005];
int sum[100005];
int a[100005], n, m;

int tc;

struct rmq{
    int tree[270000], lim;
    void init(int n){
        for(lim = 1; lim <= n; lim <<= 1);
        fill(tree,tree+270000,1e9);
    }
    void add(int x, int v){
        x += lim;
        tree[x] = v;
        while(x>1){
            x >>= 1;
            tree[x] = min(tree[2*x],tree[2*x+1]);
        }
    }
}rmq;

int main(){
    scanf("%d %d",&n,&m);
    for (int i=1; i<=n; i++) {
        scanf("%d",&a[i]);
    }
    dp[n+1] = 0;
    cnt[n+1] = 1;
    sum[0] = m;
    rmq.init(m);
    for (int i=1; i<=m; i++) {
        nxt[i] = n+1;
        rmq.add(i,0);
    }
    for (int i=n; i>=0; i--) {
        dp[i] = rmq.tree[1] + 1;
        cnt[i] = sum[dp[i] - 1];
        rmq.add(a[i],dp[i]);
        sum[dp[nxt[a[i]]]] -= cnt[nxt[a[i]]];
        sum[dp[nxt[a[i]]]] += mod;
        sum[dp[nxt[a[i]]]] %= mod;
        sum[dp[i]] += cnt[i];
        sum[dp[i]] %= mod;
        nxt[a[i]] = i;
    }
    printf("%d %d",dp[0],cnt[0]);
}