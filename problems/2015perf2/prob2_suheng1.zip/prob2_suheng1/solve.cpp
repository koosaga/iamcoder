#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <functional>
#include <vector>
#include <numeric>
#include <deque>
#include <utility>
#include <bitset>
#include <iostream>
using namespace std;
typedef long long lint;
typedef long double llf;
typedef pair<int, int> pi;
const int mod = 1e9 + 7;

int n, m, ret, a[100005];

bool trial(int x){
	lint cnt = 1;
	for(int i=1; i<=x; i++) cnt *= m;
	set<vector<int>> s;
	for(int i=1; i<=n-x+1; i++){
		vector<int> v;
		for(int j=0; j<x; j++){
			v.push_back(a[i+j]);
		}
		s.insert(v);
	}
	ret = (cnt - s.size()) % mod;
	return cnt != s.size();
}

int main(){
	scanf("%d %d",&n,&m);
	if(m == 1){
		printf("%d 1",n+1);
		return 0;
	}
	for(int i=1; i<=n; i++){
		scanf("%d",&a[i]);
	}
	int l = 1;
	while(!trial(l)) l++;
	printf("%d %d",l, ret);
}