#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <functional>
#include <vector>
#include <numeric>
#include <deque>
#include <utility>
#include <bitset>
#include <iostream>
using namespace std;
typedef long long lint;
typedef long double llf;
typedef pair<int, int> pi;

struct pt{
	int x, y, idx, pos;
};

vector<pt> hull;

int n;
pt a[100005];
lint ret[100005], lsum[100005], rsum[100005];
bool vis[100005];

bool operator<(pt a, pt b){
	return a.x == b.x ? (a.y < b.y) : (a.x < b.x);
}

long long ccw(pt a, pt b, pt c){
	int dx1 = b.x - a.x;
	int dy1 = b.y - a.y;
	int dx2 = c.x - a.x;
	int dy2 = c.y - a.y;
	return 1ll * dx1 * dy2 - 1ll * dy1 * dx2;
}

long long naive(int p){
	vector<pt> tmp1, tmp2;
	for(int i=0; i<n; i++){
		if(i == p) continue;
		tmp1.push_back(a[i]);
	}
	swap(tmp1[0], *min_element(tmp1.begin(), tmp1.end()));
	sort(tmp1.begin()+1, tmp1.end(), [&](const pt &p, const pt &q){
		return ccw(tmp1[0], p, q) > 0;
	});
	for(auto &i : tmp1){
		while(tmp2.size() >= 2 && ccw(tmp2[tmp2.size()-2], tmp2.back(), i) < 0){
			tmp2.pop_back();
		}
		tmp2.push_back(i);
	}
	long long ret = 0;
	for(int i=1; i<tmp2.size()-1; i++){
		ret += ccw(tmp2[0], tmp2[i], tmp2[i+1]);
	}
	return ret;
}

int main(){
	scanf("%d",&n);
	for(int i=0; i<n; i++){
		scanf("%d %d",&a[i].x, &a[i].y);
		a[i].idx = i;
	}
	swap(a[0], *min_element(a, a+n));
	sort(a+1, a+n, [&](const pt &p, const pt &q){
		return ccw(a[0], p, q) > 0;
	});
	for(int i=0; i<n; i++){
		a[i].pos = i;
	}
	for(int i=0; i<n; i++){
		while(hull.size() >= 2 && ccw(hull[hull.size()-2], hull.back(), a[i]) < 0){
			hull.pop_back();
		}
		hull.push_back(a[i]);
	}
	for(auto &i : hull){
		vis[i.idx] = 1;
	}
	long long base = 0;
	for(int i=1; i<hull.size()-1; i++){
		base += ccw(hull[0], hull[i], hull[i+1]);
	}
	for(int i=1; i<hull.size(); i++){
		lsum[i] = lsum[i-1] + ccw(hull[0], hull[i-1], hull[i]);
	}
	for(int i=hull.size()-2; i>=0; i--){
		rsum[i] = rsum[i+1] + ccw(hull[0], hull[i], hull[i+1]);
	}
	for(int i=1; i<hull.size()-1; i++){
		int st = hull[i-1].pos;
		int ed = hull[i+1].pos;
		vector<pt> tmp;
		for(int j=st; j<=ed; j++){
			if(j == hull[i].pos){
				continue;
			}
			while(tmp.size() >= 2 && ccw(tmp[tmp.size()-2], tmp.back(), a[j]) < 0){
				tmp.pop_back();
			}
			tmp.push_back(a[j]);
		}
		lint sum = lsum[i-1] + rsum[i+1];
		for(int i=0; i<tmp.size()-1; i++){
			sum += ccw(hull[0], tmp[i], tmp[i+1]);
		}
		ret[hull[i].idx] = sum;
	}
	ret[a[0].idx] = naive(0);
	ret[a[n-1].idx] = naive(n-1);
	for(int i=1; i<n-1; i++){
		if(!vis[a[i].idx]){
			ret[a[i].idx] = base;
		}
	}
	for(int i=0; i<n; i++){
		printf("%lld.%d00\n",ret[i] / 2, 5 * (ret[i] % 2));
	}
}